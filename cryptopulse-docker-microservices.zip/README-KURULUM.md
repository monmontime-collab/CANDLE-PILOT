# CryptoPulse Pro - Go Mikroservis, GORM, MySQL & Çok Platformlu Docker Kurulum Kılavuzu

Bu paket; **Apple Silicon (Mac M1/M2/M3/M4 - arm64)** ve **Windows (x86_64 - amd64)** bilgisayarların her ikisinde de sorunsuz çalışacak şekilde tasarlanmış mikroservis mimarisini, Docker imaj yapılandırmalarını ve GitHub Actions CI/CD dosyalarını içerir.

---

## 1. Hızlı Başlangıç (Tek Komutla Docker İmajlarını Ayağa Kaldırma)

Bilgisayarınızda **Docker Desktop** kurulu ve açık olmalıdır.

### Seçenek A: Apple (Mac - Apple Silicon M1/M2/M3/M4) Bilgisayarda Çalıştırma
Terminal'i açın, indirdiğiniz ZIP dosyasını çıkardığınız klasöre gidin ve şu komutu çalıştırın:
```bash
chmod +x start-mac-apple-silicon.sh
./start-mac-apple-silicon.sh
```
*(Alternatif olarak doğrudan `docker compose up -d --build` komutunu çalıştırabilirsiniz).*

### Seçenek B: Windows (10 / 11) Bilgisayarda Çalıştırma
İndirdiğiniz klasörün içindeki **`start-windows.bat`** dosyasına çift tıklayın veya PowerShell / CMD ekranında şu komutu çalıştırın:
```powershell
docker compose up -d --build
```

---

## 2. Hem Apple (arm64) Hem Windows (amd64) İçin Ortak Docker İmajı Üretme (Docker Buildx)

Bir bilgisayarı Apple'dan, bir bilgisayarı Windows'tan canlıya alacağınız için **Multi-Arch (Çoklu Mimari)** Docker imajı hazırlama komutu:

```bash
# 1. Çoklu platform builder'ı oluşturun ve aktif edin
docker buildx create --name multiarch-builder --use
docker buildx inspect --bootstrap

# 2. Hem Apple (linux/arm64) hem Windows/Linux (linux/amd64) için tek imaj derleyip Docker Hub'a gönderin:
docker buildx build --platform linux/amd64,linux/arm64 \
  -t kullaniciadiniz/cryptopulse-platform:latest \
  --push .
```

Sadece kendi bilgisayarınızda yerel Docker imajı oluşturmak için:
```bash
docker build -t cryptopulse-platform:latest .
```

---

## 3. Mikroservis Portları ve Servis Haritası

| Servis Adı | Port | Teknoloji | Görev |
| :--- | :--- | :--- | :--- |
| **Frontend Terminal** | `3000` | Angular / Web UI | Mum Grafiği, Pine Editör, Backtest, Replay |
| **Auth Service** | `8081` | Go + Gin + GORM + JWT | Kullanıcı Kayıt/Giriş ve JWT Token Doğrulama |
| **Market WS Service** | `8082` | Go + Gorilla WebSocket | Binance Canlı Kline & Derinlik Veri Akışı |
| **Strategy Service** | `8083` | Go + Pine Engine | İndikatör Hesaplama ve Strateji Backtest Motoru |
| **Sentiment Service** | `8084` | Go + DeepInfra LLM | Reddit, Twitter (X) & Haber Duygu Analizi |
| **MySQL 8.0** | `3306` | MySQL + GORM | İlişkisel Veritabanı (Kullanıcılar, Emirler, Stratejiler) |
| **Redis** | `6379` | Redis 7 Alpine | Yüksek Frekanslı İşlem (HFT) Önbellek & Pub/Sub |

---

## 4. GitHub Actions CI/CD Otomatik Dağıtım Kurulumu

`.github/workflows/deploy.yml` dosyası her `git push` işleminde otomatik olarak:
1. Go mikroservis birim testlerini ve arayüz testlerini çalıştırır.
2. QEMU ve Docker Buildx ile `linux/amd64` ve `linux/arm64` imajlarını derler.
3. Sunucunuza bağlanarak yeni konteynerleri sıfır kesintiyle devreye alır.

GitHub deponuzun **Settings > Secrets and variables > Actions** bölümüne şu değişkenleri eklemeniz yeterlidir:
- `DOCKERHUB_USERNAME`
- `DOCKERHUB_TOKEN`
- `SERVER_HOST`, `SERVER_USER`, `SERVER_SSH_KEY`
